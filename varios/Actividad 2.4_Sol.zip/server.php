<?php
Foreach ($_SERVER as $clave=>$valor)
	echo " $clave => $valor"."<br>";

?>